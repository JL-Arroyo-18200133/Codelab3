package com.example.artspace

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArtGalleryApp()
        }
    }
}


@Composable
fun ArtGalleryApp() {
    val currentArtwork = remember { mutableStateOf(1) }

    Surface(color = Color.Black) {
        Column {

            Image(
                painter = painterResource(id = getArtworkResourceId(currentArtwork.value)),
                contentDescription = null,
                modifier = Modifier.size(200.dp)
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 16.dp)
            )
            Box(
                modifier = Modifier
                    //.fillMaxWidth()
                    .padding(16.dp)
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .align(Alignment.CenterHorizontally)

            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        text = getArtworkTitle(currentArtwork.value),
                        style = TextStyle(fontWeight = FontWeight.Bold),
                        color = Color.Black,
                        modifier = Modifier.align(Alignment.CenterHorizontally)

                    )
                    Text(
                        text = getArtworkArtist(currentArtwork.value),
                        style = TextStyle(fontStyle = FontStyle.Italic),
                        color = Color.Black,
                        modifier = Modifier.padding(top = 8.dp).align(Alignment.CenterHorizontally)
                    )
                }
            }
            Row {
                Button(
                    onClick = { currentArtwork.value -= 1 },
                    modifier = Modifier.padding(16.dp),
                    colors = ButtonDefaults.buttonColors(Color.Red)
                ) {
                    Text(text = "Anterior", color = Color.White)
                }
                Button(
                    onClick = { currentArtwork.value += 1 },
                    modifier = Modifier.padding(16.dp),
                    colors = ButtonDefaults.buttonColors(Color.Green)
                ) {
                    Text(text = "Siguiente", color = Color.White)
                }
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ArtGalleryApp()
}

fun getArtworkResourceId(artworkId: Int): Int {
    return when (artworkId) {
        1 -> R.drawable.ei
        2 -> R.drawable.eula
        3 -> R.drawable.yelan
        else -> R.drawable.ei
    }
}

fun getArtworkTitle(artworkId: Int): String {
    return when (artworkId) {
        1 -> "Ei"
        2 -> "Eula"
        3 -> "Yelan"
        else -> ""
    }
}

fun getArtworkArtist(artworkId: Int): String {
    return when (artworkId) {
        1 -> "Electro"
        2 -> "Cryo"
        3 -> "Hydro"
        else -> ""
    }
}
